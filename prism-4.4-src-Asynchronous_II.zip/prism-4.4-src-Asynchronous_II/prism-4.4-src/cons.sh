for k in 4 6 8 10 12 14 16 18 20 ; do
./bin/prism examples/mdps/consensus/coin4.nm examples/mdps/consensus/steps_max.pctl -s -ii:upper=1.2e+12  -const K=$k -maxiters 95034634 -topological -backward > log/cons/coin4_$k\_bk_scc.log

./bin/prism examples/mdps/consensus/coin4.nm examples/mdps/consensus/steps_max.pctl -s -ii:upper=1.2e+12 -const K=$k -maxiters 95034634 -topological -improvedBK > log/cons/coin4_$k\_improved_scc.log

./bin/prism examples/mdps/consensus/coin4.nm examples/mdps/consensus/steps_max.pctl -s -ii:upper=1.2e+12 -const K=$k -maxiters 95034634 -topological -improvedmpi > log/cons/coin4_$k\_improved_mpi_scc.log

./bin/prism examples/mdps/consensus/coin4.nm examples/mdps/consensus/steps_max.pctl -s -ii:upper=1.2e+12  -const K=$k -maxiters 95034634 -backward > log/cons/coin4_$k\_bk.log

./bin/prism examples/mdps/consensus/coin4.nm examples/mdps/consensus/steps_max.pctl -s -ii:upper=1.2e+12 -const K=$k -maxiters 95034634 -improvedBK > log/cons/coin4_$k\_improved.log

./bin/prism examples/mdps/consensus/coin4.nm examples/mdps/consensus/steps_max.pctl -s -ii:upper=1.2e+12 -const K=$k -maxiters 95034634 -improvedmpi > log/cons/coin4_$k\_improved_mpi.log

./bin/prism examples/mdps/consensus/coin4.nm examples/mdps/consensus/steps_max.pctl -s -ii:upper=1.2e+12 -const K=$k -maxiters 95034634 -modpoliter > log/cons/coin4_$k\_Asynch.log
done

for k in 2 4 6 8 10 12 ; do
./bin/prism examples/mdps/consensus/coin5.nm examples/mdps/consensus/steps_max.pctl -s -ii:upper=1.2e+12  -const K=$k -maxiters 95034634 -topological -backward > log/cons/coin5_$k\_bk_scc.log

./bin/prism examples/mdps/consensus/coin5.nm examples/mdps/consensus/steps_max.pctl -s -ii:upper=1.2e+12 -const K=$k -maxiters 95034634 -topological -improvedBK > log/cons/coin5_$k\_improved_scc.log

./bin/prism examples/mdps/consensus/coin5.nm examples/mdps/consensus/steps_max.pctl -s -ii:upper=1.2e+12  -const K=$k -maxiters 95034634 -backward > log/cons/coin5_$k\_bk.log

./bin/prism examples/mdps/consensus/coin5.nm examples/mdps/consensus/steps_max.pctl -s -ii:upper=1.2e+12 -const K=$k -maxiters 95034634 -improvedBK > log/cons/coin5_$k\_improved.log

./bin/prism examples/mdps/consensus/coin5.nm examples/mdps/consensus/steps_max.pctl -s -ii:upper=1.2e+12 -const K=$k -maxiters 95034634 -improvedmpi > log/cons/coin5_$k\_improved_mpi.log

./bin/prism examples/mdps/consensus/coin5.nm examples/mdps/consensus/steps_max.pctl -s -ii:upper=1.2e+12 -const K=$k -maxiters 95034634 -topological -improvedmpi > log/cons/coin5_$k\_improved_mpi_scc.log

./bin/prism examples/mdps/consensus/coin5.nm examples/mdps/consensus/steps_max.pctl -s -ii:upper=1.2e+12 -const K=$k -maxiters 95034634 -modpoliter > log/cons/coin5_$k\_Asynch.log	
done

