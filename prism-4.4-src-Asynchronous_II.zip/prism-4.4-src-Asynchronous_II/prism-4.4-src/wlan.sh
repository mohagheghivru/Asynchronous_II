for k in 0; do
for ttm in 100 500 1000 1500 2000 2500 3000; do
./bin/prism examples/mdps/wlan/wlan5.nm examples/mdps/wlan/num_collisions.pctl -s -ii:upper=1205090 -const COL=$k,TRANS_TIME_MAX=$ttm -backward -maxiters 900500 > log/wlan/wlan5_$k\_$ttm\_bk.log

./bin/prism examples/mdps/wlan/wlan5.nm examples/mdps/wlan/num_collisions.pctl -s -ii:upper=1205090 -const COL=$k,TRANS_TIME_MAX=$ttm -improvedBK -maxiters 900500 > log/wlan/wlan5_$k\_$ttm\_improvedbk.log

./bin/prism examples/mdps/wlan/wlan5.nm examples/mdps/wlan/num_collisions.pctl -s -ii:upper=1205090 -const COL=$k,TRANS_TIME_MAX=$ttm -modpoliter -maxiters 900500 > log/wlan/wlan5_$k\_$ttm\_asynch.log

./bin/prism examples/mdps/wlan/wlan5.nm examples/mdps/wlan/num_collisions.pctl -s -ii:upper=1205090 -const COL=$k,TRANS_TIME_MAX=$ttm -improvedBK -topological -maxiters 458900500 > log/wlan/wlan5_$k\_$ttm\_improvedbk_scc.log

./bin/prism examples/mdps/wlan/wlan5.nm examples/mdps/wlan/num_collisions.pctl -s -ii:upper=1205090 -const COL=$k,TRANS_TIME_MAX=$ttm -backward -topological -maxiters 458900500 > log/wlan/wlan5_$k\_$ttm\_bk_scc.log
done
done

for k in 0; do
for ttm in 10 40 100 250 500 800 1200 1600; do
./bin/prism examples/mdps/wlan/wlan6.nm examples/mdps/wlan/num_collisions.pctl -s -ii:upper=1205090 -const COL=$k,TRANS_TIME_MAX=$ttm -backward -maxiters 900500 > log/wlan/wlan6_$k\_$ttm\_bk.log

./bin/prism examples/mdps/wlan/wlan6.nm examples/mdps/wlan/num_collisions.pctl -s -ii:upper=1205090 -const COL=$k,TRANS_TIME_MAX=$ttm -improvedBK -maxiters 900500 > log/wlan/wlan6_$k\_$ttm\_improvedbk.log

./bin/prism examples/mdps/wlan/wlan6.nm examples/mdps/wlan/num_collisions.pctl -s -ii:upper=1205090 -const COL=$k,TRANS_TIME_MAX=$ttm -modpoliter -maxiters 900500 > log/wlan/wlan6_$k\_$ttm\_asynch.log

./bin/prism examples/mdps/wlan/wlan6.nm examples/mdps/wlan/num_collisions.pctl -s -ii:upper=1205090 -const COL=$k,TRANS_TIME_MAX=$ttm -improvedBK -topological -maxiters 458900500 > log/wlan/wlan6_$k\_$ttm\_improvedbk_scc.log

./bin/prism examples/mdps/wlan/wlan6.nm examples/mdps/wlan/num_collisions.pctl -s -ii:upper=1205090 -const COL=$k,TRANS_TIME_MAX=$ttm -backward -topological -maxiters 458900500 > log/wlan/wlan6_$k\_$ttm\_bk_scc.log
done
done
