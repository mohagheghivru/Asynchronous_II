/**
 * A parser for a simple PTA input language - not used in PRISM.
 */
package pta.parser;
