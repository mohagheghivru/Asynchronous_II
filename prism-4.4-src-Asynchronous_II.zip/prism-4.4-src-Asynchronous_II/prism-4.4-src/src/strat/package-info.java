/**
 * Classes to represent/manipulate strategies (of MDPs, games, etc.)
 */
package strat;
