/**
 * Various utility classes for the graphical user interface (GUI).
 */
package userinterface.util;
