/**
 * Model editing/construction functionality in the GUI ("Model" tab)
 */
package userinterface.model;
