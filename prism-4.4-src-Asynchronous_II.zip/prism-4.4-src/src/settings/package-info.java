/**
 * Generic 'settings' functionality.
 */
package settings;
