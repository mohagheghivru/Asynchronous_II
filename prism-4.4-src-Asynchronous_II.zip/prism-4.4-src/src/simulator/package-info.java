/**
 * The discrete event simulation engine and approximate (statistical) model checking code.
 */
package simulator;
