/**
 * The main Prism API, the command-line tool, and Java classes for symbolic data structures and algorithms.
 *
 * See {@link prism.Prism} for details.
 */
package prism;
