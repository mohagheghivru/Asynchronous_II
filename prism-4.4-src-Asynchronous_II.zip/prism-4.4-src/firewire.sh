
for delay in  12 24 36; do

./bin/prism mdps/firewire/firewire.nm mdps/firewire/time_sending.pctl -const delay=$delay -s -ii:upper=246000 -maxiters 95034634 -topological -backward > log/firewire/firewire_$delay\_SCC_bk.log

./bin/prism mdps/firewire/firewire.nm mdps/firewire/time_sending.pctl -const delay=$delay -s -ii:upper=246000 -maxiters 95034634 -topological -improvedBK > log/firewire/firewire_$delay\_improved_scc.log

./bin/prism mdps/firewire/firewire.nm mdps/firewire/time_sending.pctl -const delay=$delay -s -ii:upper=246000 -maxiters 95034634 -backward > log/firewire/firewire_$delay\_bk.log

./bin/prism mdps/firewire/firewire.nm mdps/firewire/time_sending.pctl -const delay=$delay -s -ii:upper=246000 -maxiters 95034634 -improvedBK > log/firewire/firewire_$delay\_improved.log

./bin/prism mdps/firewire/firewire.nm mdps/firewire/time_sending.pctl -const delay=$delay -s -ii:upper=246000 -maxiters 95034634 -topological -modpoliter > log/firewire/firewire_$delay\_Asynch.log

done
