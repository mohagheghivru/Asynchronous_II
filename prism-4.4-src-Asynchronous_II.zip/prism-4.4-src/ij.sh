for k in 16 18 20 22 ; do

./bin/prism examples/mdps/ij/ij$k\.nm examples/mdps/ij/steps.pctl -s -ii:upper=595 -improvedBK > log/ij/ij$k\_improved_bk.log

./bin/prism examples/mdps/ij/ij$k\.nm examples/mdps/ij/steps.pctl -s -ii:upper=595 -improvedBK -topological > log/ij/ij$k\_improved_bk_SCC.log

./bin/prism examples/mdps/ij/ij$k\.nm examples/mdps/ij/steps.pctl -s -ii:upper=595 -backward > log/ij/ij$k\_backward.log

./bin/prism examples/mdps/ij/ij$k\.nm examples/mdps/ij/steps.pctl -s -ii:upper=595 -modpoliter > log/ij/ij$k\_Asynch.log

./bin/prism examples/mdps/ij/ij$k\.nm examples/mdps/ij/steps.pctl -s -cuddmaxmem 3500m -ii:upper=595 -backward -topological > log/ij/ij$k\_backward_scc.log

done
