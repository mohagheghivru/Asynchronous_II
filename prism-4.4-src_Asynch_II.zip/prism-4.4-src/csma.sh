./bin/prism mdps/csma/csma3_4.nm mdps/csma/time_max.pctl -s -maxiters 98400200 -ii:upper=718599 -backward -ddextraactionvars 240500 -cuddmaxmem 5500m > log/csma/csma_3_4_bk.log

./bin/prism mdps/csma/csma3_4.nm mdps/csma/time_max.pctl -s -maxiters 98400200 -ii:upper=718599 -modpoliter -ddextraactionvars 240500 -cuddmaxmem 5500m > log/csma/csma_3_4_Asynch.log

./bin/prism mdps/csma/csma3_4.nm mdps/csma/time_max.pctl -s -maxiters 98400200 -ii:upper=718599 -improvedBK -ddextraactionvars 240500 -cuddmaxmem 5500m > log/csma/csma_3_4_improved.log

./bin/prism mdps/csma/csma3_4.nm mdps/csma/time_max.pctl -s -maxiters 98400200 -ii:upper=718599 -topological -improvedBK -ddextraactionvars 240500 -cuddmaxmem 5500m > log/csma/csma_3_4_improved_SCC.log

./bin/prism mdps/csma/csma3_4.nm mdps/csma/time_max.pctl -s -maxiters 98400200 -ii:upper=718599 -topological -backward -ddextraactionvars 240500 -cuddmaxmem 5500m > log/csma/csma_3_4_bk_SCC.log

./bin/prism mdps/csma/csma3_5.nm mdps/csma/time_max.pctl -s -maxiters 98400200 -ii:upper=5718599 -backward -ddextraactionvars 240500 -cuddmaxmem 5500m > log/csma/csma_3_5_bk.log

./bin/prism mdps/csma/csma3_5.nm mdps/csma/time_max.pctl -s -maxiters 98400200 -ii:upper=5718599 -modpoliter -ddextraactionvars 240500 -cuddmaxmem 5500m > log/csma/csma_3_5_Asynch.log

./bin/prism mdps/csma/csma3_5.nm mdps/csma/time_max.pctl -s -maxiters 98400200 -ii:upper=5718599 -improvedBK -ddextraactionvars 240500 -cuddmaxmem 5500m > log/csma/csma_3_5_improved.log

./bin/prism mdps/csma/csma3_5.nm mdps/csma/time_max.pctl -s -maxiters 98400200 -ii:upper=5718599 -topological -improvedBK -ddextraactionvars 240500 -cuddmaxmem 5500m > log/csma/csma_3_5_improved_SCC.log

./bin/prism mdps/csma/csma3_5.nm mdps/csma/time_max.pctl -s -maxiters 98400200 -ii:upper=5718599 -topological -backward -ddextraactionvars 240500 -cuddmaxmem 5500m > log/csma/csma_3_5_bk_SCC.log


./bin/prism mdps/csma/csma4_2.nm mdps/csma/time_max.pctl -s -maxiters 98400200 -ii:upper=718599 -backward -ddextraactionvars 240500 -cuddmaxmem 5500m > log/csma/csma_4_2_bk.log

./bin/prism mdps/csma/csma4_2.nm mdps/csma/time_max.pctl -s -maxiters 98400200 -ii:upper=718599 -modpoliter -ddextraactionvars 240500 -cuddmaxmem 5500m > log/csma/csma_4_2_Asynch.log

./bin/prism mdps/csma/csma4_2.nm mdps/csma/time_max.pctl -s -maxiters 98400200 -ii:upper=718599 -improvedBK -ddextraactionvars 240500 -cuddmaxmem 5500m > log/csma/csma_4_2_improved.log

./bin/prism mdps/csma/csma4_2.nm mdps/csma/time_max.pctl -s -maxiters 98400200 -ii:upper=718599 -topological -improvedBK -ddextraactionvars 240500 -cuddmaxmem 5500m > log/csma/csma_4_2_improved_SCC.log

./bin/prism mdps/csma/csma4_2.nm mdps/csma/time_max.pctl -s -maxiters 98400200 -ii:upper=718599 -topological -backward -ddextraactionvars 240500 -cuddmaxmem 5500m > log/csma/csma_4_2_bk_SCC.log

./bin/prism mdps/csma/csma4_3.nm mdps/csma/time_max.pctl -s -maxiters 98400200 -ii:upper=8718599 -backward -ddextraactionvars 240500 -cuddmaxmem 5500m > log/csma/csma_4_3_bk.log

./bin/prism mdps/csma/csma4_3.nm mdps/csma/time_max.pctl -s -maxiters 98400200 -ii:upper=8718599 -modpoliter -ddextraactionvars 240500 -cuddmaxmem 5500m > log/csma/csma_4_3_Asynch.log

./bin/prism mdps/csma/csma4_3.nm mdps/csma/time_max.pctl -s -maxiters 98400200 -ii:upper=8718599 -improvedBK -ddextraactionvars 240500 -cuddmaxmem 5500m > log/csma/csma_4_3_improved.log

./bin/prism mdps/csma/csma4_3.nm mdps/csma/time_max.pctl -s -maxiters 98400200 -ii:upper=8718599 -topological -improvedBK -ddextraactionvars 240500 -cuddmaxmem 5500m > log/csma/csma_4_3_improved_SCC.log

./bin/prism mdps/csma/csma4_3.nm mdps/csma/time_max.pctl -s -maxiters 98400200 -ii:upper=8718599 -topological -backward -ddextraactionvars 240500 -cuddmaxmem 5500m > log/csma/csma_4_3_bk_SCC.log

