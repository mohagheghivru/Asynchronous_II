This case study is based on Rabin's solution to the well known mutual exclusion problem [Rab82].

For more information, see: http://www.prismmodelchecker.org/casestudies/rabin.php

=====================================================================================

[Rab82]
M. Rabin
N-Process Mutual Exclusion with Bounded Waiting by 4log2N-Valued Shared Variable
Journal of Computer and System Sciences, 25(1):66-75, 1982




