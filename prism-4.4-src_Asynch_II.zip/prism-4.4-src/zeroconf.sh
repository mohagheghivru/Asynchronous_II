for k in  10 12 14 16 18; do
./bin/prism examples/mdps/zeroconf/zeroconf.nm examples/mdps/zeroconf/max_cost.pctl -s -ii:upper=190 -improvedBK -maxiters 900500 -const N=1000,K=$k,err=.1 > log/zeroconf/zeroconf_improved_$k\.log

./bin/prism examples/mdps/zeroconf/zeroconf.nm examples/mdps/zeroconf/max_cost.pctl -s -ii:upper=1e+32 -backward -maxiters 900500 -const N=1000,K=$k,err=.1 > log/zeroconf/zeroconf_bk_$k\.log

./bin/prism examples/mdps/zeroconf/zeroconf.nm examples/mdps/zeroconf/max_cost.pctl -s -ii:upper=1e+32 -modpoliter -maxiters 900500 -const N=1000,K=$k,err=.1 > log/zeroconf/zeroconf_Asynch_$k\.log

./bin/prism examples/mdps/zeroconf/zeroconf.nm examples/mdps/zeroconf/max_cost.pctl -s -ii:upper=190 -improvedBK -topological -maxiters 85900500 -const N=1000,K=$k,err=.1 > log/zeroconf/zeroconf_improved_SCC_$k\.log

./bin/prism examples/mdps/zeroconf/zeroconf.nm examples/mdps/zeroconf/max_cost.pctl -s -ii:upper=1e+32 -backward -topological -maxiters 85900500 -const N=1000,K=$k,err=.1 > log/zeroconf/zeroconf_bk_SCC_$k\.log
done

