for k in 4 5 6; do

./bin/prism examples/mdps/asyncleader/leader$k.nm examples/mdps/asyncleader/rounds.pctl -s -ii:upper=595 -improvedBK  -maxiters 59000500 -javamaxmem 4500m > log/leader/leader_improved_$k\.log

./bin/prism examples/mdps/asyncleader/leader$k.nm examples/mdps/asyncleader/rounds.pctl -s -ii:upper=595 -improvedBK -topological -maxiters 59000500 -javamaxmem 4500m > log/leader/leader_improved_SCC_$k\.log

./bin/prism examples/mdps/asyncleader/leader$k.nm examples/mdps/asyncleader/rounds.pctl -s -ii -backward -maxiters 59000500 -javamaxmem 4500m > log/leader/leader_bk_$k\.log

./bin/prism examples/mdps/asyncleader/leader$k.nm examples/mdps/asyncleader/rounds.pctl -s -ii -backward -topological -maxiters 59000500 -javamaxmem 4500m > log/leader/leader_bk_SCC_$k\.log

done;
for k in 7; do

./bin/prism examples/mdps/asyncleader/leader$k.nm examples/mdps/asyncleader/rounds.pctl -s -ii:upper=595 -improvedBK  -maxiters 59000500 -javamaxmem 4500m > log/leader/leader_improved_$k\.log

./bin/prism examples/mdps/asyncleader/leader$k.nm examples/mdps/asyncleader/rounds.pctl -s -ii:upper=595 -improvedBK -topological -maxiters 59000500 -javamaxmem 4500m > log/leader/leader_improved_SCC_$k\.log

./bin/prism examples/mdps/asyncleader/leader$k.nm examples/mdps/asyncleader/rounds.pctl -s -ii:upper=650000 -backward -maxiters 59000500 -javamaxmem 4500m > log/leader/leader_bk_$k\.log

./bin/prism examples/mdps/asyncleader/leader$k.nm examples/mdps/asyncleader/rounds.pctl -s -ii:upper=650000 -backward -topological -maxiters 59000500 -javamaxmem 4500m > log/leader/leader_bk_SCC_$k\.log
done;

for k in 8; do
./bin/prism examples/mdps/asyncleader/leader$k.nm examples/mdps/asyncleader/rounds.pctl -s -ii:upper=595 -improvedBK  -maxiters 59000500 -javamaxmem 4500m > log/leader/leader_improved_$k\.log

./bin/prism examples/mdps/asyncleader/leader$k.nm examples/mdps/asyncleader/rounds.pctl -s -ii:upper=595 -improvedBK -topological -maxiters 59000500 -javamaxmem 4500m > log/leader/leader_improved_SCC_$k\.log

./bin/prism examples/mdps/asyncleader/leader$k.nm examples/mdps/asyncleader/rounds.pctl -s -ii:upper=7650000 -backward -maxiters 59000500 -javamaxmem 4500m > log/leader/leader_bk_$k\.log

./bin/prism examples/mdps/asyncleader/leader$k.nm examples/mdps/asyncleader/rounds.pctl -s -ii:upper=7550000 -backward -topological -maxiters 59000500 -javamaxmem 4500m > log/leader/leader_bk_SCC_$k\.log
done;
